
import { _decorator, Component, Node, Prefab, instantiate } from 'cc';
import { Main } from './main';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = Target
 * DateTime = Sat Feb 26 2022 15:48:35 GMT+0700 (Indochina Time)
 * Author = alipbudiman12
 * FileBasename = target.ts
 * FileBasenameNoExtension = target
 * URL = db://assets/script/target.ts
 * ManualUrl = https://docs.cocos.com/creator/3.3/manual/en/
 *
 */
 
@ccclass('Target')
export class Target extends Component {
    @property is_death : boolean = false;

    death() {
        console.log('death')
        this.scheduleOnce(()=>{
            console.log(this.is_death)
            if (this.is_death == false){
                this.is_death = true;  
                this.node.destroy();    
            }
        },3);
    }

    start () {
        this.death()
    }

    // update (deltaTime: number) {
    //     // [4]
    // }
}
