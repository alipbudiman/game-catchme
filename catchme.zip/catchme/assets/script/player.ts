
import { _decorator, Component, Node, Vec3, systemEvent, SystemEvent, SystemEventType, KeyCode, EventKeyboard, Animation, Collider2D, IPhysics2DContact, BoxCollider2D, Contact2DType, instantiate } from 'cc';
import { Main } from './main';
import { Target } from './target';
const { ccclass, property } = _decorator;

 
@ccclass('Player')
export class Player extends Component {
    movment_speed = 10;

    core_x : number = 0;
    core_y : number = 0;
    angel : number = 0;

    max_x : number = 360;
    min_x : number = -360;

    max_y : number = 800;
    min_y : number = -800;

    is_player_death : boolean = false;

    private fx_hit = null;

    @property ({ type : Node  }) explosion : Node = null;

    onLoad () {
        systemEvent.on(SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
        let colider = this.node.getComponent(BoxCollider2D);
        colider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
    }

    Death (){
        this.explosion.position = this.node.position;
        this.explosion.active = true;
        this.explosion.getComponent(Animation).play("anime_explosion");
        Main.call.playdeath(this.explosion);
        this.is_player_death = true;
        this.unschedule(this.deathfx);
        this.node.active = false;
    }
    onKeyDown (event: EventKeyboard) {
        switch (event.keyCode) {
            case KeyCode.KEY_D:
                this.core_y = 0;
                this.angel = -90;
                this.core_x = this.movment_speed;
                break;
            case KeyCode.KEY_W:
                this.core_x = 0;
                this.angel = 0;
                this.core_y = this.movment_speed;
                break;
            case KeyCode.KEY_A:
                this.core_y = 0;
                this.angel = 90;
                this.core_x = -this.movment_speed;
                break;
            case KeyCode.KEY_S:
                this.core_x = 0;
                this.angel = 180;
                this.core_y = -this.movment_speed;
                break;
        }
    }

    onBeginContact (selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
        // will be called once when two colliders begin to contact
        if (otherCollider.tag == 2) {
            if (otherCollider.node == null) {
                return;
            } else if (otherCollider.node.getComponent(Target).is_death == false) {
                this.scheduleOnce(()=>{
                    otherCollider.getComponent(Target).is_death = true;
                    this.fx_hit = instantiate(Main.call.prefab_fx);
                    this.fx_hit.position = this.node.position;
                    this.fx_hit.parent = Main.call.parent_fx;
                    this.scheduleOnce(this.deathfx,3);
                    otherCollider.node.destroy();
                },0.1);
            }
        }
    }

    deathfx () {
        if (this.is_player_death == false){
            this.fx_hit.destroy();
        }
    }
    

    start () {
        this.node.position = new Vec3(0, 0, 0);
    }

    update (deltaTime: number) {
        let positio_x = this.node.position.x + this.core_x;
        let positio_y = this.node.position.y + this.core_y;
        if (positio_x >= this.max_x) {
            this.Death();
        }
        else if (positio_x <= this.min_x) {
            this.Death();
        }
        else if (positio_y >= this.max_y) {
            this.Death();
        }
        else if (positio_y <= this.min_y) {
            this.Death();
        }
        this.node.eulerAngles = new Vec3(0, 0, this.angel);
        this.node.position = new Vec3(positio_x, positio_y, 0);
    }
}
