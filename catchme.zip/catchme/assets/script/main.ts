
import { _decorator, Component, Node, director, instantiate, Prefab, randomRange, Vec3 } from 'cc';
import { Target } from './target';
const { ccclass, property } = _decorator;
 
@ccclass('Main')
export class Main extends Component {
    public static call : Main

    max_x : number = 360;
    min_x : number = -360;

    max_y : number = 800;
    min_y : number = -800;

    @property({ type: Node }) popup_death : Node = null;
    @property ({type : Prefab}) prefab_target : Prefab;
    @property ({type : Node}) parent_trget : Node = null;
    @property ({type: Prefab}) prefab_fx : Prefab = null;
    @property ({type: Node}) parent_fx : Node = null; 

    onLoad(){
        Main.call = this
    }

    playdeath(explosion: Node) {
        this.scheduleOnce( () => {
            explosion.active = false;
            this.popup_death.active = true;
        },1.20);
        
    }

    playagain(){
        director.loadScene('gameplay');
    }

    spawn_target() {
        let target = instantiate(this.prefab_target);
        target.position = this.random_position();
        target.parent = this.parent_trget;
        // this.scheduleOnce(()=>{
        //     if (target.getComponent(Target).is_death == false){
        //         target.getComponent(Target).is_death = true;
        //         target.destroy();
        //     }
        // },10);
    }

    random_position(){
        let rand_x = randomRange(this.min_x, this.max_x);
        let rand_y = randomRange(this.min_y, this.max_y);

        return new Vec3(rand_x, rand_y, 0);
    }

    start () {
        this.schedule(this.spawn_target,2);
    }

    update (deltaTime: number) {

    }
}
